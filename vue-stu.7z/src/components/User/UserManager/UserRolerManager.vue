<template>
  <div class="user-roler">
    <div class="roler-left" :style="{ width: width + 'px' }"></div>
    <XHandle class="myxhandle" @widthChange="widthChange" />
    <div class="roler-right"></div>
  </div>
</template>
<script>
import XHandle from './XHandle.vue'
export default {
  components: {
    XHandle,
  },
  data() {
    return {
      width: 200,
    }
  },
  methods: {
    widthChange(movement) {
      this.width -= movement
      if (this.width < 50) {
        this.width = 50
      }
      if (this.width > 500) {
        this.width = 500
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.user-roler {
  display: flex;
  width: 100%;
  height: 100%;
  .roler-left {
    height: 100%;
    background-color: rgba(0, 0, 0, 0.1);
  }
  .roler-right {
    flex: 1;
    height: 100%;
    background-color: #f5f5f5;
  }
}
</style>

<template>
  <div class=''>
      我是用户权限管理
  </div>
</template>
<script>
export default {
  name: ''
}
</script>
<style lang='scss' scoped>

</style>

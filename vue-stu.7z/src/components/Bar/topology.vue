<template>
  <div class="topology">
    <!-- <topology />
    <br />
    <a href="https://www.yuque.com/alsmile/topology/dev-start" target="black">说明文档</a> -->
  </div>
</template>
<script>
export default {
  name: '',
  data(){
    return {
      
    }
  }
}
</script>
<style lang="scss" scoped>
.topology {
  text-align: left;
}
</style>
